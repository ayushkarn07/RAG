# app/ingest.py

import os
import time
from pathlib import Path
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
from PyPDF2 import PdfReader

# config values
from config import FAISS_INDEX_PATH, UPLOAD_DIR, EMBEDDING_MODEL

# -------------------------
# Robust imports (LangChain variations)
# -------------------------
# text splitter import (handles various versions)
try:
    from langchain_text_splitters import RecursiveCharacterTextSplitter
except Exception:
    try:
        from langchain_text_splitters import RecursiveCharacterTextSplitter
    except Exception:
        from langchain_text_splitters import RecursiveCharacterTextSplitter

# embeddings import (try langchain first, fallback to langchain_community)
try:
    from langchain.embeddings import HuggingFaceEmbeddings
except Exception:
    try:
        from langchain_community.embeddings import HuggingFaceEmbeddings
    except Exception:
        raise ImportError("HuggingFaceEmbeddings not found. Install 'langchain' or 'langchain-community' and 'sentence-transformers'.")

# FAISS vectorstore
from langchain_community.vectorstores import FAISS

# -------------------------
# Prepare embedding model
# -------------------------
# Use the model name from config (default: all-MiniLM-L6-v2)
embedding_model = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)

# -------------------------
# Helpers for FAISS folder handling
# -------------------------
def _faiss_folder_from_path(setting: str) -> Path:
    """Return the folder path used for FAISS persistence (directory)."""
    p = Path(setting)
    # If a file path was provided (has suffix), use parent directory
    if p.suffix:
        return p.parent
    return p

def _ensure_faiss_folder() -> Path:
    folder = _faiss_folder_from_path(FAISS_INDEX_PATH)
    folder.mkdir(parents=True, exist_ok=True)
    return folder

def _faiss_saved_files_exist(folder: Path) -> bool:
    # Check for common saved files LangChain FAISS writes
    # Prefer looking for index.faiss or any .faiss/.pkl/.json files
    if (folder / "index.faiss").exists():
        return True
    if any(folder.glob("*.faiss")):
        return True
    if any(folder.glob("*.pkl")):
        return True
    if any(folder.glob("*.json")):
        return True
    # otherwise assume no saved index
    return False

# -------------------------
# PDF ingestion
# -------------------------
def ingest_pdf(file_path: str) -> int:
    """
    Read a PDF, split into chunks, and add to FAISS index.
    Returns number of chunks indexed.
    """
    print(f"[ingest_pdf] Indexing PDF: {file_path}")
    reader = PdfReader(file_path)
    text_parts = []
    for page in reader.pages:
        try:
            page_text = page.extract_text()
        except Exception:
            page_text = None
        if page_text:
            text_parts.append(page_text)

    full_text = "\n".join(text_parts).strip()
    if not full_text:
        print("[ingest_pdf] No text extracted from PDF.")
        return 0

    # chunk
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
    documents = text_splitter.create_documents([full_text])
    for doc in documents:
        if not hasattr(doc, "metadata"):
            doc.metadata = {}
        doc.metadata.update({"source": str(file_path)})

    # FAISS folder
    faiss_folder = _ensure_faiss_folder()

    # Load existing index or create new using embedding_model
    if _faiss_saved_files_exist(faiss_folder):
        faiss_index = FAISS.load_local(
            str(faiss_folder),
            embedding_model,
            allow_dangerous_deserialization=True,
        )
    else:
        faiss_index = FAISS.from_documents(documents, embedding_model)

    # Add documents and persist
    faiss_index.add_documents(documents)
    faiss_index.save_local(str(faiss_folder))

    print(f"[ingest_pdf] Indexed {len(documents)} chunks from PDF.")
    return len(documents)

# -------------------------
# Website crawler + ingestion
# -------------------------
def crawl_website(seed_url: str, max_pages: int = 50, delay: float = 0.2):
    """
    Crawl seed_url and internal subpages (same domain) up to max_pages.
    Returns list of dicts: {'url':..., 'text':...}
    """
    visited = set()
    to_visit = [seed_url]
    pages = []

    domain = urlparse(seed_url).netloc

    while to_visit and len(visited) < max_pages:
        current = to_visit.pop(0)
        if current in visited:
            continue
        try:
            resp = requests.get(current, timeout=10)
            if resp.status_code != 200:
                visited.add(current)
                continue

            soup = BeautifulSoup(resp.text, "html.parser")

            # remove scripts/styles
            for tag in soup(["script", "style", "noscript"]):
                tag.decompose()

            text = soup.get_text(separator="\n").strip()
            if text:
                pages.append({"url": current, "text": text})

            visited.add(current)

            # find internal links
            for a in soup.find_all("a", href=True):
                link = urljoin(current, a["href"])
                # normalize (remove fragments)
                parsed = urlparse(link)
                normalized = parsed._replace(fragment="").geturl()
                if urlparse(normalized).netloc == domain:
                    if normalized not in visited and normalized not in to_visit:
                        to_visit.append(normalized)
        except Exception as e:
            print(f"[crawl_website] Error fetching {current}: {e}")
            visited.add(current)
        time.sleep(delay)

    return pages

def ingest_url(url: str, max_pages: int = 50) -> int:
    """
    Crawl a website (seed url + subpages), split into chunks, and add to FAISS index.
    Returns number of chunks indexed.
    """
    print(f"[ingest_url] Indexing website: {url}")
    pages = crawl_website(url, max_pages=max_pages, delay=0.2)
    if not pages:
        print("[ingest_url] No pages fetched from website.")
        return 0

    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
    documents = []
    for page in pages:
        splits = text_splitter.create_documents([page["text"]])
        for s in splits:
            if not hasattr(s, "metadata"):
                s.metadata = {}
            s.metadata.update({"source": page["url"]})
        documents.extend(splits)

    faiss_folder = _ensure_faiss_folder()

    if _faiss_saved_files_exist(faiss_folder):
        faiss_index = FAISS.load_local(
            str(faiss_folder),
            embedding_model,
            allow_dangerous_deserialization=True,
        )
    else:
        faiss_index = FAISS.from_documents(documents, embedding_model)

    faiss_index.add_documents(documents)
    faiss_index.save_local(str(faiss_folder))

    print(f"[ingest_url] Indexed {len(documents)} chunks from {len(pages)} pages.")
    return len(documents)

# -------------------------
# Convenience small test (optional)
# -------------------------
if __name__ == "__main__":
    # Quick local smoke test:
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    # Example: ingest_url("https://example.com", max_pages=5)
    # Example: ingest_pdf("data/uploads/example.pdf")
    pass
