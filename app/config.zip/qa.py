# app/qa.py
from config import USE_GROQ, TOP_K
from retriever import retrieve
from llm import call_groq

MAX_CHUNK_CHARS = 1500
MAX_CHUNKS = 10

def generate_answer(question: str):
    # Step 1: retrieve relevant chunks
    contexts = retrieve(question, top_k=TOP_K)
    if not contexts:
        return "No relevant documents found."

    # Step 2: prepare context text
    trimmed = []
    for c in contexts[:MAX_CHUNKS]:
        txt = getattr(c, "page_content", None) or getattr(c, "content", None) or ""
        if len(txt) > MAX_CHUNK_CHARS:
            txt = txt[:MAX_CHUNK_CHARS] + " ...[truncated]"
        src = getattr(c, "metadata", None) or {}
        trimmed.append({"text": txt, "source": src.get("source", "unknown")})

    ctx_text = "\n\n".join([f"SOURCE: {t['source']}\n{t['text']}" for t in trimmed])

    # Step 3: If Groq disabled, just show retrieved chunks
    if not USE_GROQ:
        return ctx_text

    # Step 4: build prompt for Groq
    prompt = (
        f"You are an assistant. Use ONLY the context below to answer the question. "
        f"If answer not present, say 'I don't know'.\n\n"
        f"CONTEXT:\n{ctx_text}\n\nQUESTION: {question}\nAnswer:"
    )

    # Step 5: call Groq
    try:
        answer = call_groq(prompt)
        if not answer:
            return ctx_text
        return answer
    except Exception as e:
        print("Error calling Groq:", e)
        return ctx_text
