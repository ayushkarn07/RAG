# app/retriever.py
from pathlib import Path
from config import FAISS_INDEX_PATH, EMBEDDING_MODEL, TOP_K
try:
    from langchain.embeddings import HuggingFaceEmbeddings as HFE
except Exception:
    from langchain_community.embeddings import HuggingFaceEmbeddings as HFE
from langchain_community.vectorstores import FAISS

# Load FAISS index with embeddings
embedding_model = HFE(model_name=EMBEDDING_MODEL)
faiss_folder = Path(FAISS_INDEX_PATH)
if faiss_folder.suffix:
    faiss_folder = faiss_folder.parent

if not faiss_folder.exists() or not any(faiss_folder.iterdir()):
    raise FileNotFoundError(f"No FAISS index found in {faiss_folder}")

vectorstore = FAISS.load_local(
    str(faiss_folder),
    embedding_model,
    allow_dangerous_deserialization=True
)

def retrieve(query: str, top_k: int = TOP_K):
    """Return top-k chunks for a query"""
    try:
        results = vectorstore.similarity_search(query, k=top_k)
        return results
    except Exception as e:
        print("Error in similarity_search:", e)
        return []
