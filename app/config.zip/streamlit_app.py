import streamlit as st
import os
from ingest import ingest_pdf, ingest_url
from qa import generate_answer
from config import UPLOAD_DIR

# Ensure upload dir exists
os.makedirs(UPLOAD_DIR, exist_ok=True)

st.set_page_config(page_title="RAG QA Chat App", layout="wide")
st.title("📄 RAG QA Chat App")

# --- Session state ---
if "messages" not in st.session_state:
    st.session_state.messages = []

# --- Sidebar: Document selection ---
st.sidebar.header("Select input type")
input_type = st.sidebar.radio("Process:", ["PDF", "Website"])

if input_type == "PDF":
    uploaded_file = st.sidebar.file_uploader("Choose a PDF file", type="pdf")
    if uploaded_file:
        save_path = os.path.join(UPLOAD_DIR, uploaded_file.name)
        with open(save_path, "wb") as f:
            f.write(uploaded_file.getbuffer())
        num_chunks = ingest_pdf(save_path)
        st.sidebar.success(f"PDF indexed! {num_chunks} chunks added.")
else:
    url_input = st.sidebar.text_input("Enter website URL")
    if st.sidebar.button("Index URL") and url_input:
        try:
            num_chunks = ingest_url(url_input)
            st.sidebar.success(f"Website indexed! {num_chunks} chunks added.")
        except Exception as e:
            st.sidebar.error(f"Failed to index URL: {e}")

# --- Chat input ---
with st.form("chat_form", clear_on_submit=True):
    user_input = st.text_input("Type your question here...", key="input")
    submitted = st.form_submit_button("Send")

if submitted and user_input:
    # Show user message
    st.session_state.messages.append({"role": "user", "content": user_input})
    
    with st.spinner("Generating answer..."):
        answer = generate_answer(user_input)
        st.session_state.messages.append({"role": "assistant", "content": answer})

# --- Display chat messages ---
for msg in st.session_state.messages:
    if msg["role"] == "user":
        with st.chat_message("user"):
            st.markdown(msg["content"])
    else:
        with st.chat_message("assistant"):
            st.markdown(msg["content"])
